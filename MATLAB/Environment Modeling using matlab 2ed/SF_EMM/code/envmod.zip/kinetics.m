% sub module for 1. order kinetics in simpltrans
c1 = exp(-lambda*dtdiff)*c1; 
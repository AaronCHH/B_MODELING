% sub module for advection step in simpltrans
c1 = circshift(c1',1)';
c1(1) = cin;
